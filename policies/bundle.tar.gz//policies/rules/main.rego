package tracepath.main

import data.tracepath.main.decision

import data.tracepath.allowlist
import data.tracepath.budget
import data.tracepath.ratelimit

default allow := false

allow if {
	budget.allow
	allowlist.allow
	ratelimit.allow
}

deny contains msg if {
	some msg in budget.deny
}

deny contains msg if {
	some msg in allowlist.deny
}

deny contains msg if {
	some msg in ratelimit.deny
}
