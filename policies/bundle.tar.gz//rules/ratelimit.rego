package tracepath.ratelimit

default max_calls_per_minute := 60

default max_calls_per_5min := 200

default allow := true

allow if {
	input.calls_last_minute <= max_calls_per_minute
}

deny contains msg if {
	input.calls_last_minute > max_calls_per_minute
	msg := sprintf(
		"rate limit exceeded: %d calls in last minute (max %d)",
		[input.calls_last_minute, max_calls_per_minute],
	)
}
