package tracepath.budget

default budget_limit := 1000

default allow := true

allow if {
	input.estimated_cost_cents + input.spent_so_far_cents <= input.budget_limit
}

deny contains msg if {
	not allow
	msg := sprintf(
		"budget exceeded: cost %d + spent %d > limit %d",
		[input.estimated_cost_cents, input.spent_so_far_cents, input.budget_limit],
	)
}
