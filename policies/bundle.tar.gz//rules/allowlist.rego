package tracepath.allowlist

agent_tools := {
	"coder": {"read_file", "write_file", "terminal", "search_files", "patch", "execute_code"},
	"researcher": {"web_search", "web_extract", "browser_navigate", "browser_snapshot"},
	"coordinator": {"delegate_task", "cronjob", "todo", "clarify"},
	"assistant": {
		"terminal", "write_file", "read_file", "search_files", "patch",
		"web_search", "web_extract",
		"browser_navigate", "browser_snapshot", "browser_click", "browser_vision",
		"delegate_task", "execute_code",
		"clarify", "memory", "session_search",
		"skill_view", "skills_list", "skill_manage",
		"tool_search", "tool_describe", "tool_call",
		"image_generate",
	},
	"default": {"read_file", "web_search", "web_extract"},
}

global_allowed contains t if {
	some tools in agent_tools
	t := tools[_]
}

default allow := false

allow if {
	global_allowed[input.tool_name]
}

allow if {
	tools := agent_tools[input.agent_type]
	tools[input.tool_name]
}

deny contains msg if {
	not allow
	msg := sprintf(
		"tool '%s' not in allowlist for agent_type '%s'",
		[input.tool_name, object.get(input, "agent_type", "unspecified")],
	)
}
